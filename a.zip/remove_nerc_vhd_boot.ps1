﻿# Run as Administrator

$ErrorActionPreference = 'Stop'

# --- Backup BCD ---
$ts = Get-Date -Format 'yyyyMMdd_HHmmss'
$bkp = "$env:SystemDrive\bcd_backup_$ts.bcd"
bcdedit /export $bkp | Out-Null
Write-Host "BCD backup saved to: $bkp"

# --- Read full BCD ---
$text = bcdedit /enum all /v
$blocks = ($text -join "`n") -split "(`r?`n){2,}"

$deleted = 0

foreach ($b in $blocks) {
    if ($b -notmatch 'identifier\s+({[^}]+})') { continue }
    $id = $Matches[1]

    if ($id -ieq '{current}') { continue }

    if ($b -match '(?i)vhd=\[[A-Z]:\]\\nerc\\output\.vhdx?' ) {
        Write-Host "Deleting boot entry $id"
        bcdedit /delete $id /f | Out-Null
        $deleted++
    }
}

# --- Set timeout ---
bcdedit /timeout 0 | Out-Null

Write-Host "Deleted entries: $deleted"
Write-Host "Boot timeout set to 0"
